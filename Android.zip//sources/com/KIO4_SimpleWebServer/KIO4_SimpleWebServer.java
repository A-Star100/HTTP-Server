package com.KIO4_SimpleWebServer;

import com.google.appinventor.components.annotations.DesignerComponent;
import com.google.appinventor.components.annotations.SimpleFunction;
import com.google.appinventor.components.annotations.SimpleObject;
import com.google.appinventor.components.annotations.UsesPermissions;
import com.google.appinventor.components.common.ComponentCategory;
import com.google.appinventor.components.runtime.AndroidNonvisibleComponent;
import com.google.appinventor.components.runtime.Component;
import com.google.appinventor.components.runtime.ComponentContainer;
import java.io.FileInputStream;
import java.io.IOException;

@SimpleObject(external = true)
@DesignerComponent(category = ComponentCategory.EXTENSION, description = "Simple web server. Supplies an HTML file or a text. Juan Antonio Villalpando - KIO4.COM ", iconName = "http://iesromerovargas.com/Imagenes/soundRecorder.png", nonVisible = true, version = 1)
@UsesPermissions(permissionNames = "android.permission.INTERNET, android.permission.ACCESS_NETWORK_STATE, android.permission.READ_EXTERNAL_STORAGE")
public class KIO4_SimpleWebServer extends AndroidNonvisibleComponent implements Component {
    public static final int VERSION = 1;
    private ComponentContainer container;
    private String texto = "";

    public KIO4_SimpleWebServer(ComponentContainer componentContainer) {
        super(componentContainer.$form());
        this.container = componentContainer;
    }

    @SimpleFunction(description = "Write an address from an HTML file in SdCard, example: /mnt/sdcard/index.htm")
    public void ServeFile(String str) throws IOException {
        StringBuffer stringBuffer = new StringBuffer("");
        byte[] bArr = new byte[8192];
        FileInputStream fileInputStream = null;
        try {
            FileInputStream fileInputStream2 = new FileInputStream(str);
            while (true) {
                try {
                    int read = fileInputStream2.read(bArr);
                    if (read != -1) {
                        stringBuffer.append(new String(bArr, 0, read));
                    } else {
                        String stringBuffer2 = stringBuffer.toString();
                        fileInputStream2.close();
                        new KIO4_SimpleWebServerCrear().onCreate(stringBuffer2);
                        return;
                    }
                } catch (Throwable th) {
                    th = th;
                    fileInputStream = fileInputStream2;
                    fileInputStream.close();
                    throw th;
                }
            }
        } catch (Throwable th2) {
            th = th2;
            fileInputStream.close();
            throw th;
        }
    }

    @SimpleFunction(description = "Write a text.")
    public void ServeText(String str) throws IOException {
        new KIO4_SimpleWebServerCrear().onCreate(str);
    }
}
