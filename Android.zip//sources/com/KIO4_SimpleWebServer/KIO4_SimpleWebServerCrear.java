package com.KIO4_SimpleWebServer;

import com.google.appinventor.components.runtime.util.NanoHTTPD;
import com.microsoft.appcenter.http.DefaultHttpClient;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import org.apache.http.HttpException;
import org.apache.http.HttpRequest;
import org.apache.http.HttpResponse;
import org.apache.http.entity.ContentProducer;
import org.apache.http.entity.EntityTemplate;
import org.apache.http.impl.DefaultConnectionReuseStrategy;
import org.apache.http.impl.DefaultHttpResponseFactory;
import org.apache.http.impl.DefaultHttpServerConnection;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.BasicHttpProcessor;
import org.apache.http.protocol.HttpContext;
import org.apache.http.protocol.HttpRequestHandler;
import org.apache.http.protocol.HttpRequestHandlerRegistry;
import org.apache.http.protocol.HttpService;
import org.apache.http.protocol.ResponseConnControl;
import org.apache.http.protocol.ResponseContent;
import org.apache.http.protocol.ResponseDate;
import org.apache.http.protocol.ResponseServer;

public class KIO4_SimpleWebServerCrear {
    public String contenido = "";
    public HttpServiceThread httpServiceThread;

    public void onCreate(String str) {
        this.contenido = str;
        HttpServiceThread httpServiceThread2 = new HttpServiceThread();
        this.httpServiceThread = httpServiceThread2;
        httpServiceThread2.start();
    }

    public class HttpServiceThread extends Thread {
        static final int HttpServerPORT = 8080;
        BasicHttpContext basicHttpContext;
        HttpService httpService;
        ServerSocket serverSocket;
        public Socket socket;

        HttpServiceThread() {
            startHttpService();
        }

        public void run() {
            try {
                ServerSocket serverSocket2 = new ServerSocket(HttpServerPORT);
                this.serverSocket = serverSocket2;
                serverSocket2.setReuseAddress(true);
                while (!Thread.currentThread().isInterrupted()) {
                    this.socket = this.serverSocket.accept();
                    DefaultHttpServerConnection defaultHttpServerConnection = new DefaultHttpServerConnection();
                    defaultHttpServerConnection.bind(this.socket, new BasicHttpParams());
                    this.httpService.handleRequest(defaultHttpServerConnection, this.basicHttpContext);
                    defaultHttpServerConnection.shutdown();
                }
                this.serverSocket.close();
                stopServer();
                KIO4_SimpleWebServerCrear.this.httpServiceThread.stop();
            } catch (IOException unused) {
                KIO4_SimpleWebServerCrear.this.httpServiceThread.stop();
                stopServer();
            } catch (HttpException unused2) {
                KIO4_SimpleWebServerCrear.this.httpServiceThread.stop();
                stopServer();
            }
        }

        public synchronized void startHttpService() {
            BasicHttpProcessor basicHttpProcessor = new BasicHttpProcessor();
            this.basicHttpContext = new BasicHttpContext();
            basicHttpProcessor.addInterceptor(new ResponseDate());
            basicHttpProcessor.addInterceptor(new ResponseServer());
            basicHttpProcessor.addInterceptor(new ResponseContent());
            basicHttpProcessor.addInterceptor(new ResponseConnControl());
            this.httpService = new HttpService(basicHttpProcessor, new DefaultConnectionReuseStrategy(), new DefaultHttpResponseFactory());
            HttpRequestHandlerRegistry httpRequestHandlerRegistry = new HttpRequestHandlerRegistry();
            httpRequestHandlerRegistry.register("/", new HomeCommandHandler());
            this.httpService.setHandlerResolver(httpRequestHandlerRegistry);
        }

        public synchronized void stopServer() {
            ServerSocket serverSocket2 = this.serverSocket;
            if (serverSocket2 != null) {
                try {
                    serverSocket2.close();
                } catch (IOException unused) {
                }
            }
        }

        class HomeCommandHandler implements HttpRequestHandler {
            HomeCommandHandler() {
            }

            public void handle(HttpRequest httpRequest, HttpResponse httpResponse, HttpContext httpContext) throws HttpException, IOException {
                EntityTemplate entityTemplate = new EntityTemplate(new ContentProducer() {
                    public void writeTo(OutputStream outputStream) throws IOException {
                        OutputStreamWriter outputStreamWriter = new OutputStreamWriter(outputStream, "UTF-8");
                        outputStreamWriter.write(KIO4_SimpleWebServerCrear.this.contenido);
                        outputStreamWriter.flush();
                    }
                });
                httpResponse.setHeader(DefaultHttpClient.CONTENT_TYPE_KEY, NanoHTTPD.MIME_HTML);
                httpResponse.setEntity(entityTemplate);
            }
        }
    }
}
