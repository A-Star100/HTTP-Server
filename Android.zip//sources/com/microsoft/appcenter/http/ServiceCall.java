package com.microsoft.appcenter.http;

public interface ServiceCall {
    void cancel();
}
