package com.microsoft.appcenter;

public final class R {
}
